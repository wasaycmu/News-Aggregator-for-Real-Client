# InstagramSearch
A python library for searching most recent hashtags via Instagrams search engine.

The post about this can be found at http://tomkdickinson.co.uk/2016/12/extracting-instagram-data-part-1/
