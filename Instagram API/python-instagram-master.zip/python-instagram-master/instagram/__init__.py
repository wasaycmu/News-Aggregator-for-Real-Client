from .bind import InstagramAPIError, InstagramClientError
from .client import InstagramAPI
